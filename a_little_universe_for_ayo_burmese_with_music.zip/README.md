# အရိုးအတွက် ကြယ်ကမ္ဘာလေး

မြန်မာဘာသာဖြင့် ပြုလုပ်ထားသော မွေးနေ့ဝက်ဘ်ဆိုက်လေးပါ။

## သီချင်းထည့်ရန်
1. `music` folder ထဲသို့ သင်တရားဝင်ရရှိထားသော MP3 ဖိုင်ကို ထည့်ပါ။
2. ဖိုင်အမည်ကို `phyay-ph yay-lay-ma-ngo-pr-net-amara-hphone.mp3` ဟု အတိအကျ ပြောင်းပါ။
3. `index.html` နှင့် `music` folder နှစ်ခုလုံးကို GitHub repository သို့ upload လုပ်ပါ။
4. Website ကိုဖွင့်ပြီး Enter ခလုတ်ကိုနှိပ်ပါ။ ထိုအချိန်တွင် သီချင်းစတင်ဖွင့်ပါမည်။

မှတ်ချက် - သီချင်းဖိုင်ကို မူပိုင်ခွင့်ခွင့်ပြုချက်ရှိသောနေရာမှ ကိုယ်တိုင်ရယူပါ။ ဤ ZIP ထဲတွင် သီချင်း MP3 မပါဝင်ပါ။

## GitHub Pages ဖြင့် အွန်လိုင်းတင်ရန်
1. GitHub တွင် repository အသစ်တစ်ခု ဖန်တီးပါ။
2. `index.html` နှင့် `music` folder ကို repository ၏ အပြင်ဆုံးနေရာတွင် upload လုပ်ပါ။
3. **Settings → Pages** ကိုဖွင့်ပါ။
4. **Deploy from a branch** ကိုရွေးပါ။
5. Branch ကို `main`၊ folder ကို `/(root)` ရွေးပြီး Save လုပ်ပါ။
6. GitHub Pages မှ ပေးသော link ကိုဖွင့်ပါ။
